package com.jwt.upc.security.enums;

public enum RoleList {
    ROLE_ADMIN, ROLE_USER
}
