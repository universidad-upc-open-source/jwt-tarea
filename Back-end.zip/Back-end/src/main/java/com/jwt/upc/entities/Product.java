package com.jwt.upc.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "productos")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    @NotNull
    @Column(name = "nombre")
    private String name;
    @NotNull
    private Integer stock;

    @NotNull
    @Column(name = "precio")
    private Double price;

    @NotNull
    @Column(name = "codigo")
    private String sku;

    public Product() {
    }

    public Product(String id, @NotNull String name, @NotNull Integer stock, @NotNull Double price, @NotNull String sku) {
        this.id = id;
        this.name = name;
        this.stock = stock;
        this.price = price;
        this.sku = sku;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }
}
