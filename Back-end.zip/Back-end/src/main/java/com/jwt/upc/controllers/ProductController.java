package com.jwt.upc.controllers;

import java.util.List;

import javax.validation.Valid;

import com.jwt.upc.entities.Message;
import com.jwt.upc.entities.Product;
import com.jwt.upc.response.Response;
import com.jwt.upc.response.ResponseHandler;
import com.jwt.upc.services.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/producto")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET}, allowedHeaders = "*")
public class ProductController {
    @Autowired
    private Environment env;

    private final ProductService productService;

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/lista")
    public ResponseEntity<List<Product>> getAll() {
        List<Product> foundProducts = this.productService.getAll();
        return new ResponseEntity<>(foundProducts, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping()
    // public ResponseEntity<Message> save(@Valid @RequestBody Product product, BindingResult bindingResult) {
    public ResponseEntity<Object> save(@Valid @RequestBody Product product, BindingResult bindingResult) {
        if (bindingResult.hasErrors()){
            Response response = new Response(
                    env.getProperty("response.code.error"),
                    env.getProperty("response.status.error"),
                    env.getProperty("response.service.ok"),
                    env.getProperty("response.data.error"),
                    "Los campos ingresados son incorrectos",
                    ""
            );
            return ResponseHandler.generateResponse(HttpStatus.OK, false, response.responseDataJSON("productRegister"), response.responseJSON());
            // return new ResponseEntity<>(new Message("Los campos ingresados son incorrectos"), HttpStatus.BAD_REQUEST);
        }

        this.productService.create(product);

        //return new ResponseEntity<>(new Message("Producto guardado"), HttpStatus.OK);

        Response response = new Response(
                env.getProperty("response.code.ok"),
                env.getProperty("response.status.ok"),
                env.getProperty("response.service.ok"),
                env.getProperty("response.data.ok"),
                "Producto creado",
                ""
        );
        return ResponseHandler.generateResponse(HttpStatus.OK, false, response.responseDataJSON("productRegister"), response.responseJSON());

    }
}
