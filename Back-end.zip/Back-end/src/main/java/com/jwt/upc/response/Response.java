package com.jwt.upc.response;


import com.fasterxml.jackson.annotation.JsonCreator;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Response {

    private String code ;
    private String status ;
    private String description ;


    private String codrpta ;
    private String msgrpta;
    private Object data;



    @JsonCreator
    public Response(String code, String status, String description, String codrpta, String msgrpta, Object data ) {
        this.code = code;
        this.status = status;
        this.description = description;

        this.codrpta = codrpta;
        this.msgrpta = msgrpta;
        this.data = data;
    }
    public Map<String, Object> responseJSON() {
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("code", this.code);
        data.put("status", this.status);
        data.put("description", this.description);
        JSONObject json = new JSONObject(data);
        return json.toMap();
    }

    public Map<String, Object> responseDataJSON(String key) {
        HashMap<String, HashMap<String, Object>> data = new HashMap<String, HashMap<String,Object>>();
        data.put(key, new HashMap<String, Object>() );
        data.get(key).put("codrpta" , this.codrpta);
        data.get(key).put("msgrpta" , this.msgrpta);
        data.get(key).put("data" , this.data);
        JSONObject json = new JSONObject(data);
        return json.toMap();
    }


}
