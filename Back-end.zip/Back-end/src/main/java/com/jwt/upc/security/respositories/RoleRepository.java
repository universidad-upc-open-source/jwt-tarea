package com.jwt.upc.security.respositories;

import java.util.Optional;

import com.jwt.upc.security.entities.Role;
import com.jwt.upc.security.enums.RoleList;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository <Role, Integer> {
    Optional<Role> findByRoleName(RoleList roleName);
    
}
