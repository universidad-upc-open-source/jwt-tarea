package com.jwt.upc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuritySApplicationTests {

	@Test
	void contextLoads() {
	}

}
