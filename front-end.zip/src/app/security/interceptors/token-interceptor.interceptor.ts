import { JwtHelperService } from '@auth0/angular-jwt';
import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable()
export class TokenInterceptorInterceptor implements HttpInterceptor {

  constructor(
    private route: Router,
  ) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const routerWithToken = this.route.url.includes('private');
    const jwtHelper = new JwtHelperService();
    const headers = request.headers;
    const token = localStorage.getItem('token');
    let _requestClone = {}

    if(routerWithToken){
      if(token){
        _requestClone = {
          ..._requestClone,
          headers:
            new HttpHeaders()
              .set('Authorization', `Bearer ${token}`)
        }
      }
      return next.handle(request.clone(_requestClone))
    }
    return next.handle(request);
  }
}
