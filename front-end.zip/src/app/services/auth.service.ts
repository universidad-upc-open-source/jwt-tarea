import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { IAuthLogin } from '../interfaces/auth';
import { ServicesService } from './services.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private services: ServicesService,
    private router : Router
  ) { }


  postLogin(data:IAuthLogin){
    return   this.services.postQuery( data ,'auth/login' ).pipe();
  }

  logout(){
    this.router.navigate(['/public']).then(() => {
      localStorage.removeItem('token');
    })
  }


}
