import { Injectable } from '@angular/core';
import { IProductList } from '../interfaces/products';
import { ServicesService } from './services.service';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(
    private services: ServicesService
  ) { }

  getList(){
    return  this.services.getQuery<IProductList[]>('producto/lista');
  }


}
