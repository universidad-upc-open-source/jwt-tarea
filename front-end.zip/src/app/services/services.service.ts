import { FormGroup } from '@angular/forms';
import { environment } from './../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { delay, tap } from 'rxjs';

const apiUrl = environment.apiEndPoint;

@Injectable({
  providedIn: 'root',
})
export class ServicesService {
  constructor(private http: HttpClient, private router: Router) {}

  public getQuery<T>(query: string, respType?: any, millSeconds?: number) {
    query = `${apiUrl}/${query}`;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    if (!respType) {
      respType = 'json';
    }
    if (!millSeconds) {
      millSeconds = 200;
    }
    return this.http
      .get<T>(query, { headers, responseType: respType })
      .pipe(delay(millSeconds));
  }

  public postQuery<T>(
    body: any,
    nameService: string,
    respType?: any,
    millSeconds?: number
  ) {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    if (!respType) {
      respType = 'json';
    }
    const url = `${apiUrl}/${nameService}`;
    if (!millSeconds) {
      millSeconds = 200;
    }
    return this.http
      .post<T>(url, body, { headers, responseType: respType })
      .pipe(delay(millSeconds));
  }

  markFormGroupTouched(formGroup: FormGroup) {
    (Object as any).values(formGroup.controls).forEach((control) => {
      control.markAsTouched();
      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
