import { Injectable } from '@angular/core';
import { IResponseStructure } from '../interfaces/common';
import { ErrorDataModel, ErrorResultModel } from '../interfaces/response';

@Injectable({
  providedIn: 'root',
})
export class ErrorService {
  private resultSuccessCodes = ['0000'];
  private dataSuccessCodes = ['00'];

  constructor() {}

  private resultItsSuccess(resultCode) {
    return this.resultSuccessCodes.includes(resultCode);
  }

  processResultError(result: ErrorResultModel, onError, onSuccess) {
    if (result && result.code) {
      if (this.resultItsSuccess(result.code)) {
        onSuccess();
      } else {
        console.log('BBBB')
        onError(result.description || '');
      }
    } else {
      onError('Ocurrió un error. Vuelva a intentarlo.');
    }
  }

  getFirstKeyOfData(data) {
    return Object.keys(data)[0];
  }

  private dataItsSuccess(dataCode) {
    return this.dataSuccessCodes.includes(dataCode);
  }

  processDataError(dataCode, onError, onSuccess) {
    if (this.dataItsSuccess(dataCode)) {
      onSuccess();
    } else {
      onError();
    }
  }

  handleError({ result, data }: IResponseStructure, onSuccess, onError) {
    const resultTyped = result as ErrorResultModel;
    this.processResultError(
      resultTyped,
      () => {
        if (resultTyped && resultTyped.description) {
          onError(resultTyped.description);
        } else {
          onError('Ocurrió un error. Vuelva a intentarlo.');
        }
      },
      () => {
        const dataTyped = data[this.getFirstKeyOfData(data)] as ErrorDataModel;
        this.processDataError(
          dataTyped.codrpta,
          () => {
            onError(dataTyped.msgrpta);
          },
          () => {
            onSuccess(dataTyped.msgrpta);
          }
        );
      }
    );
  }
}
