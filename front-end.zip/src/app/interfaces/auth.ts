export interface IAuthLogin{
    userName : string;
    password : string;
}