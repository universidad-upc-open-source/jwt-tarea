export interface IProductList{
  id: string;
  name: string;
  stock: number;
  price: number;
  sku: string;
}