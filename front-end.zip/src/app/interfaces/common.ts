interface IResponseBody {
  codrpta: string;
  msgrpta: string;
  token: string;
}

interface IResponseResult {
  code: string;
  status: string;
  description: string;
}

export interface IResponseStructure {
  result: {};
  data: {};
}

export interface ResponseModel<T> {
  data: T;
  result: IResponseResult;
}
