export interface ErrorResultModel {
  code: string;
  status: string;
  description: string;
}
export interface ErrorDataModel {
  codrpta: string;
  msgrpta: string;
}
