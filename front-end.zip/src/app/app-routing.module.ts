import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IsActiveGuardGuard } from './guards/is-active-guard.guard';
import { PrivateComponent } from './pages/private/private.component';
import { PublicComponent } from './pages/public/public.component';

const routes: Routes = [
  {
    path: 'public',
    component: PublicComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/public/public.module').then((m) => m.PublicModule),
      },
    ],
  },
  {
    path: 'private',
    component: PrivateComponent,
    canActivate: [IsActiveGuardGuard],
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/private/private.module').then((m) => m.PrivateModule),
      },
    ],
  },
  {
    path: '**',
    redirectTo: 'public',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
