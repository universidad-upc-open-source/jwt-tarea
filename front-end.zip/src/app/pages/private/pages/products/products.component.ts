import { IProductList } from './../../../../interfaces/products';
import { ProductsService } from './../../../../services/products.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  products: IProductList[] = [];
  constructor(private sProduct: ProductsService) {}

  ngOnInit(): void {
    this.sProduct.getList().subscribe((response) => {
      this.products = response;
      console.log('products', response);
    });
  }
}
