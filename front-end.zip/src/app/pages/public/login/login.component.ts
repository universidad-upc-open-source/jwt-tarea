import { Router } from '@angular/router';
import { ErrorService } from './../../../services/error.service';
import { IAuthLogin } from './../../../interfaces/auth';
import { AuthService } from './../../../services/auth.service';
import { ServicesService } from './../../../services/services.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  fg: FormGroup;

  constructor(
    private fb: FormBuilder,
    private services: ServicesService,
    private sAuth: AuthService,
    private errorService: ErrorService,
    private router : Router
  ) {
    this.createForm();
  }

  ngOnInit(): void {}

  createForm() {
    this.fg = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  enviar() {
    if (this.fg.invalid) {
      alert('Verifique los campos del formulario');
      this.services.markFormGroupTouched(this.fg);
      return;
    }
    const data: IAuthLogin = {
      userName: this.fg.controls['username'].value,
      password: this.fg.controls['password'].value,
    };
    this.sAuth.postLogin(data).subscribe(({ data, result }) => {
      const token = data;
      this.errorService.handleError(
        { data, result },
        () => {
          localStorage.setItem('token' , data['loginAuth'].data.token);
          this.router.navigate(['/private','productos'])
          console.log('data!' , token)
        },
        (message) => {
          console.log('error:' , message)
        }
      );

    });
  }

  get validateFields() {
    return (campo: any) => {
      return this.fg.get(campo).invalid && this.fg.get(campo).touched;
    };
  }
}
